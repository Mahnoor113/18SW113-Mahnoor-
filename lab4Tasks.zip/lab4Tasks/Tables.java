import java.util.Scanner;

class Tables
{
public static void main(String args[])
{
        int i,j,k,l;

        System.out.println("Enter range of numbers to print their multiplication tables");

        Scanner in = new Sacnner(System.in);

        a=in.nextInt();
        b=in.nextInt();

        for(k=i;k<=j;k++){
        System.out.println("Multiplication table of "+k);
        }
        for(l=1;l<=10;l++){|System.out.println(k+"*"+l+"="+(k*l));
        }
         }
          }