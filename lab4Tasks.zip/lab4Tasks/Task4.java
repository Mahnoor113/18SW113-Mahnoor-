class Task4
{
public static void main(String args[])
{
int[][]arr1={{1,2,3},{4,5,6},{7,8,9}};
int[][]arr2={{1,1,1},{2,2,2},{3,3,3}};
for(int i=0;i<arr1.length;i++){
for(int j=0;l<arr1[i].length;j++){
System.out.println("Result["+i+"]["+j+"]=");
System.out.println(arr1[i][j]+arr2[i][j]);
}
}
}
}