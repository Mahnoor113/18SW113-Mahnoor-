import java.util.Scanner;
public class Task6
{
    public static void main(String args[])
    {
    
       int[] myArray = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
       
       System.out.println("Enter the number for search in array");
       
       Scanner scan=new Scanner(System.in);
       int num=scan.nextInt();
       
       for(int i=0; i<myArray.length; i++){
       if(num == myArray[i]){
       System.out.println("Array contains the given element");
       }
       else
       {
       System.out.println("Entered Number is not present in arrays");
       
       }
        } 
         } 
          }