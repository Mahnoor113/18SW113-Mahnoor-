import java.util.Scanner;

class TaskNo4
{
public static void main(String[] args)
{
         int x,y, add,multi,division ,sub;

         System.out.println("Enter two integers to calculate their sum");
         Scanner in = new Scanner(System.in);

         x=in.nextInt();
         y=in.nextInt();
         z= x + y;

         System.out.println("Sum of the two integers = " + z);

         sub=x-y;
         System.out.println("Subraction of the two  integers = " + sub);

         multi=x*y;
         System.out.println("Multiplication of the two integers= " +  multi);

         division=x/y;
         Ststem.out.println("Division of the two integers = " + division);

         }
          }