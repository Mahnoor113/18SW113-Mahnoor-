class TaskOnWhile
{
public static void main(String[] args)
{
while(i<=50){
}
if(i%2==0){
System.out.println("Even Number is =   "+i);
}
else
{
System.out.println("odd Number is =     "+i);
}
}
}
