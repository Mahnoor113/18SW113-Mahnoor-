class BinaryToDecimal
{
public static void main(String[] args)
{
System.out.println(Integer.parseInt("1010",2));
System.out.println(Integer.parseInt("10101",2));
}
}