class Alphabate
{
public static void main(String[] args)
{
       char ch;
       for(ch=65; ch<=90 ; ch++){
       System.out.println(ch);
       }
       }
   }