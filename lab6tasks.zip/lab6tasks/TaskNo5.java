class Student
{
	    String name;
		int age;
		String address;
		Student()						//default constructor
		{ 
			name="null";
			age=0;
			address="not available";


		} 								//first constructor end
		void SetInfo(String name,int age)      //parameterized mehod
        {
        	this.name=name;
        	System.out.println("Name:"+name);
        	this.age=age;
        	System.out.println("Age:"+age);
        }  									//end method
        void SetInfo(String name,int age,String address)					//parameterized method
        {
             this.name=name;
             System.out.print("\n\n\n");
             System.out.println("Name:"+name);
             this.age=age;
             System.out.println("Age :"+age);
             this.address=address;
             System.out.println("Address:"+address);
        }												//2nd method end
}   

class Task5
{
         public static void main(String args [])
         			{
         				Student [] obj=new Student[10];
         				Student obj1=new Student();
         				obj[0]=new Student();
         				obj[0].SetInfo("Mahnoor",113,"Muet");
         				obj[1]=new Student();
         				obj[1].SetInfo("Asra",103,"Muet");
                                        obj[2]=new Student();
         				obj[2].SetInfo("Amina",10,"Muet");
         				obj[3]=new Student();
         				obj[3].SetInfo("Rabia",112,"Muet");
         				obj[4]=new Student();
         				obj[4].SetInfo("Aasia,18,"Muet");
         				obj[5]=new Student();
         				obj[5].SetInfo("Saima",20,"Muet");
         				obj[6]=new Student();
         				obj[6].SetInfo("Farwa",17,"Muet");
         				obj[7]=new Student();
         				obj[7].SetInfo("Kashaf",30,"Muet");
         				obj[8]=new Student();
         				obj[8].SetInfo("Aqsa",40,"Muet");
         				obj[9]=new Student();
         				obj[9].SetInfo("Umema",28,"Muet");
                                      


                       
         			
         			}
}

