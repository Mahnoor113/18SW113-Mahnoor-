class ClassWork
{
public static void main(String[] args)
{

        outer:
       for(int i=0; i<=10; i++)
       {
       for(int j=0; j<5; j++)
       {
       if(j==2)
       break;
       System.out.print(j);
       }
       System.out.println();

       }
        }
         }