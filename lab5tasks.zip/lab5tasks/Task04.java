class Task04{
	String name;
	String dept;
	String rollno;
	Task04(String name,String dept,String rollno){
		this.name=name;
		this.dept=name;
		this.rollno=rollno;
		System.out.print(name+" "+dept+" "+rollno);


	}
	public static void main(String args[]){
    Task04 s1=new Task04("Mahnoor","Software-Engineering","18SW113");
}
	}