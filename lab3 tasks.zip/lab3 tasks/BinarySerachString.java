public class BinarySearchString
{
public static void main(String[] args)

{
         string[] a={"Mahnoor", "Misbah","Maheen", "Maira" ,"Mehwish", "Hania" ,"fatima""};
         int srch= "Maira";
         int min=0;
         int max=a.length-1;
         int mid;
         string s ="Hania";

         while(min<==max)
         {
         if(a([mid]==srch)
         {
         System.out.println("String is at "+mid+" index position");
         }
         else if(a[mid]<srch)
         {
         min+mid+1
         }
         else
         {
         max=mid=1;
         }
         mid;
         }
         if(min>max)
         {
         System.out.println("String not found");
         }
         }




