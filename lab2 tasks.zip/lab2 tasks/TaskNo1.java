class TaskNo1
{
public static void main(String[] args)
{
System.out.println("Your first argument is: "+args[0]);
System.out.println("Your second argument is: "+args[1]);
}
}
