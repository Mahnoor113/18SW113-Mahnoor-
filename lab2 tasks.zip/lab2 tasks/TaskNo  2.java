class TaskNo 2
{
public static void main(String[] args)
{
       int x=5, y=3, z;
       z= x+y;
       System.out.println("x+y == "+z);
       System.out.println("x+y != "+z);

       }
}
