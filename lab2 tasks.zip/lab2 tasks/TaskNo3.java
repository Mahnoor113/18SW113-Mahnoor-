class TaskNo3
{
public static void main(String[] args)
{
       float a=3.141f, b=2.11f, c=4.22f, d=1.21f, e=1.55f, sum , average;
              sum=a+b+c+d+e;
          average=sum/5;
          System.out.println("Sum of numbers are="+sum);
          System.out.println("Average of numbers are="+average);
	  }
  }