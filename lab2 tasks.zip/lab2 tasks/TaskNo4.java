class TaskNo4
{

public static void main(String[]args)
{
int r=2;
float f=3.14f;
double d=4;
long diam=2*r;
double circ=2*f*r;
double area=f*r*r;
System.out.println("Diameter is:"+diam);
System.out.println("Circle is:"+circ);
System.out.println("Area is:"+area);
}
}